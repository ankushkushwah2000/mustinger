<?php

return [
    'razor_key' => 'rzp_test_cO43UnnLKgQndx',
    'razor_secret' => 'zAcsdMRW6QqBrLTZ0OvcV3C8'
];
