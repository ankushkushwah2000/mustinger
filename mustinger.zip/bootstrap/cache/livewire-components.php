<?php return array (
  'allcategoriesselect' => 'App\\Http\\Livewire\\Allcategoriesselect',
  'categories-select' => 'App\\Http\\Livewire\\CategoriesSelect',
  'order-status' => 'App\\Http\\Livewire\\OrderStatus',
);