<?php


use App\Models\Cart;

/* Cart single item calculation */

function calculate(Cart $cart)
{
}
